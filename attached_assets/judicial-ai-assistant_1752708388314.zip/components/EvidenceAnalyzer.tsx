
import React, { useState, useCallback } from 'react';
import { analyzeImage } from '../services/geminiService';
import LoadingSpinner from './common/LoadingSpinner';
import ResultCard from './common/ResultCard';
import * as historyService from '../services/historyService';
import type { User } from '../types';

interface EvidenceAnalyzerProps {
    currentUser: User | null;
}

const EvidenceAnalyzer: React.FC<EvidenceAnalyzerProps> = ({ currentUser }) => {
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [imagePreview, setImagePreview] = useState<string | null>(null);
    const [prompt, setPrompt] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [result, setResult] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            if (file.size > 4 * 1024 * 1024) { // 4MB limit
                setError("File is too large. Please select a file smaller than 4MB.");
                return;
            }
            setImageFile(file);
            const reader = new FileReader();
            reader.onloadend = () => {
                setImagePreview(reader.result as string);
            };
            reader.readAsDataURL(file);
            setError(null);
        }
    };

    const handleSubmit = useCallback(async () => {
        if (!imageFile || !prompt.trim() || !currentUser) {
            setError('Please upload an image and enter a question.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setResult(null);

        const base64Data = imagePreview?.split(',')[1];

        if (!base64Data) {
            setError("Could not read image file.");
            setIsLoading(false);
            return;
        }

        try {
            const analysis = await analyzeImage(base64Data, imageFile.type, prompt);
            setResult(analysis);
            historyService.addHistoryItem(currentUser.id, {
                type: 'evidence-analyzer',
                input: { question: prompt, fileName: imageFile.name },
                output: { analysis: analysis },
            });
        } catch (err: unknown) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, [imageFile, imagePreview, prompt, currentUser]);
    
    const isButtonDisabled = isLoading || !imageFile || !prompt.trim();

    return (
        <div>
            <h2 className="text-3xl font-bold font-serif text-white">Evidence Analyzer</h2>
            <p className="mt-2 text-slate-400">Upload an image of evidence (e.g., from a crime scene or document) and ask a specific question about its contents.</p>
            
            <div className="mt-6 p-6 bg-slate-800/50 border border-slate-700 rounded-lg space-y-4">
                <div>
                    <label htmlFor="file-upload" className="block text-sm font-medium text-slate-300 mb-2">1. Upload Image</label>
                    <input 
                        id="file-upload"
                        type="file" 
                        accept="image/png, image/jpeg, image/webp"
                        onChange={handleFileChange}
                        className="block w-full text-sm text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-amber-500/10 file:text-amber-300 hover:file:bg-amber-500/20"
                        disabled={isLoading}
                    />
                </div>
                
                {imagePreview && (
                    <div className="p-4 border border-slate-600 rounded-md bg-slate-900/50">
                        <img src={imagePreview} alt="Evidence preview" className="max-h-64 w-auto mx-auto rounded-md"/>
                    </div>
                )}
                
                <div>
                    <label htmlFor="image-prompt" className="block text-sm font-medium text-slate-300 mb-2">2. Ask a Question</label>
                    <input
                        id="image-prompt"
                        type="text"
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder="e.g., 'What object is the person holding?' or 'Transcribe the text in this document.'"
                        className="w-full p-3 bg-slate-800 border border-slate-700 rounded-md focus:ring-2 focus:ring-amber-400 focus:border-amber-400 transition-colors"
                        disabled={isLoading || !imageFile}
                    />
                </div>
            </div>

            <div className="mt-4">
                <button
                    onClick={handleSubmit}
                    disabled={isButtonDisabled}
                    className="px-6 py-2 bg-amber-600 text-white font-semibold rounded-md hover:bg-amber-700 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
                >
                    {isLoading ? 'Analyzing...' : 'Analyze Evidence'}
                </button>
            </div>

            {isLoading && <LoadingSpinner />}
            {error && <div className="mt-6 p-4 bg-red-900/50 border border-red-700 text-red-300 rounded-md">{error}</div>}
            {result && (
                <ResultCard title="Forensic Analysis">
                    <p>{result}</p>
                </ResultCard>
            )}
        </div>
    );
};

export default EvidenceAnalyzer;
