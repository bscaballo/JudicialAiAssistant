import React from 'react';
import type { DraftedOrder } from '../../types';

interface FormattedOrderProps {
    order: DraftedOrder;
    className?: string;
}

const FormattedOrder: React.FC<FormattedOrderProps> = ({ order, className = '' }) => {
    return (
        <div className={`font-serif bg-white text-gray-800 p-8 rounded-md shadow-lg max-w-full text-left ${className}`}>
            <div className="text-center">
                <p className="font-bold">{order.courtName.toUpperCase()}</p>
                <p>COUNTY OF [Specify County], STATE OF NEW MEXICO</p>
            </div>

            <hr className="my-6 border-gray-400" />

            <div className="my-4">
                <p className="font-bold">{order.caseStyle}</p>
                <p><span className="font-bold">Case No.:</span> {order.caseNumber}</p>
                <p>{order.division}</p>
            </div>

            <hr className="my-6 border-gray-400" />

            <div className="text-center my-6">
                <p className="font-bold text-lg uppercase">{order.orderTitle}</p>
            </div>

            <p className="my-4">{order.introduction}</p>
            <p className="my-4">The Court, having reviewed the pleadings, evidence, and arguments of counsel, finds and concludes as follows:</p>

            <div className="my-6">
                <p className="font-bold">FINDINGS OF FACT</p>
                <ol className="list-decimal list-inside ml-4 space-y-2">
                    {order.findingsOfFact.map((fact, index) => <li key={index}>{fact}</li>)}
                </ol>
            </div>

            <div className="my-6">
                <p className="font-bold">CONCLUSIONS OF LAW</p>
                <ol className="list-decimal list-inside ml-4 space-y-2">
                    {order.conclusionsOfLaw.map((conclusion, index) => <li key={index}>{conclusion}</li>)}
                </ol>
            </div>

            <hr className="my-6 border-gray-400" />

            <p className="my-4 font-bold">IT IS THEREFORE ORDERED, ADJUDGED, AND DECREED that:</p>
            <p className="my-4">{order.orderClause}</p>

            <p className="my-4 font-bold">IT IS SO ORDERED.</p>

            <div className="mt-16">
                <p className="w-1/2 border-t border-gray-800 pt-2">{order.signatureLine}</p>
                <p className="font-bold">Hon. Lori Gibson Willard</p>
                <p>Division II</p>
            </div>
        </div>
    );
};

export default FormattedOrder;