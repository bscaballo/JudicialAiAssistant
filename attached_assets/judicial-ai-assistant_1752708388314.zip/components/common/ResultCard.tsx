
import React from 'react';

interface ResultCardProps {
    title: string;
    children: React.ReactNode;
}

const ResultCard: React.FC<ResultCardProps> = ({ title, children }) => {
    return (
        <div className="mt-8 bg-slate-800 border border-slate-700 rounded-lg shadow-lg">
            <div className="px-6 py-4 border-b border-slate-700">
                <h3 className="text-xl font-serif font-bold text-amber-300">{title}</h3>
            </div>
            <div className="p-6 prose prose-invert prose-sm md:prose-base max-w-none text-slate-300 whitespace-pre-wrap">
                {children}
            </div>
        </div>
    );
};

export default ResultCard;
