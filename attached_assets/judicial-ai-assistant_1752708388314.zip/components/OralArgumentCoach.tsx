
import React, { useState, useCallback, useRef, useEffect } from 'react';
import type { Chat } from '@google/genai';
import type { ChatMessage, User } from '../types';
import { createChatSession } from '../services/geminiService';
import * as historyService from '../services/historyService';
import LoadingSpinner from './common/LoadingSpinner';
import { UserCircleIcon, BriefcaseIcon, PaperAirplaneIcon } from './common/Icons';

interface OralArgumentCoachProps {
    currentUser: User | null;
}

const OralArgumentCoach: React.FC<OralArgumentCoachProps> = ({ currentUser }) => {
    const [chatSession, setChatSession] = useState<Chat | null>(null);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const [caseContext, setCaseContext] = useState('');
    const [aiRole, setAiRole] = useState<'Plaintiff' | 'Defendant'>('Plaintiff');
    const [currentMessage, setCurrentMessage] = useState('');

    const chatContainerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (chatContainerRef.current) {
            chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
        }
    }, [messages]);

    const handleStartSimulation = useCallback(() => {
        if (!caseContext.trim() || !currentUser) {
            setError('Please provide some background for the case.');
            return;
        }
        setError(null);
        const session = createChatSession(caseContext, aiRole);
        setChatSession(session);
        setMessages([
            {
                role: 'model',
                text: `I am ready to begin the oral argument for the ${aiRole}. You may begin with your questions, Your Honor.`
            }
        ]);
        historyService.addHistoryItem(currentUser.id, {
            type: 'oral-argument-coach',
            input: { caseContext: caseContext, aiRepresents: aiRole },
            output: { result: 'Simulation started.' },
        });
    }, [caseContext, aiRole, currentUser]);
    
    const handleSendMessage = useCallback(async () => {
        if (!currentMessage.trim() || !chatSession) return;

        const newUserMessage: ChatMessage = { role: 'user', text: currentMessage };
        setMessages(prev => [...prev, newUserMessage]);
        setCurrentMessage('');
        setIsLoading(true);

        try {
            const response = await chatSession.sendMessage({ message: currentMessage });
            const modelMessage: ChatMessage = { role: 'model', text: response.text };
            setMessages(prev => [...prev, modelMessage]);
        } catch (err: unknown) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred while communicating with the AI.');
        } finally {
            setIsLoading(false);
        }
    }, [currentMessage, chatSession]);

    const handleReset = () => {
        setChatSession(null);
        setMessages([]);
        setCaseContext('');
        setError(null);
        setIsLoading(false);
    };

    if (!chatSession) {
        return (
            <div>
                <h2 className="text-3xl font-bold font-serif text-white">Oral Argument Coach</h2>
                <p className="mt-2 text-slate-400">Set up the simulation to practice your questions for an upcoming hearing.</p>
                
                <div className="mt-6 space-y-4 p-6 bg-slate-800/50 border border-slate-700 rounded-lg">
                    <div>
                        <label htmlFor="case-context" className="block text-sm font-medium text-slate-300 mb-2">Case Background & Facts</label>
                        <textarea
                            id="case-context"
                            value={caseContext}
                            onChange={(e) => setCaseContext(e.target.value)}
                            placeholder="Briefly describe the case, the motion being argued, and the key facts..."
                            className="w-full h-48 p-3 bg-slate-800 border border-slate-700 rounded-md focus:ring-2 focus:ring-amber-400 focus:border-amber-400 transition-colors"
                        />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-slate-300 mb-2">AI Represents:</label>
                        <div className="flex gap-4">
                           {['Plaintiff', 'Defendant'].map((role) => (
                                <button key={role} onClick={() => setAiRole(role as 'Plaintiff' | 'Defendant')}
                                    className={`px-4 py-2 rounded-md transition-colors text-sm font-semibold ${aiRole === role ? 'bg-amber-600 text-white' : 'bg-slate-700 hover:bg-slate-600'}`}>
                                    {role}
                                </button>
                           ))}
                        </div>
                    </div>
                    <div>
                         <button
                            onClick={handleStartSimulation}
                            disabled={!caseContext.trim()}
                            className="px-6 py-2 bg-amber-600 text-white font-semibold rounded-md hover:bg-amber-700 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
                        >
                            Start Simulation
                        </button>
                    </div>
                </div>
                 {error && <div className="mt-6 p-4 bg-red-900/50 border border-red-700 text-red-300 rounded-md">{error}</div>}
            </div>
        );
    }

    return (
         <div>
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-3xl font-bold font-serif text-white">Argument Simulation</h2>
                <button
                    onClick={handleReset}
                    className="px-4 py-2 text-sm bg-slate-700 text-slate-300 font-semibold rounded-md hover:bg-slate-600 transition-colors"
                >
                    New Simulation
                </button>
            </div>
            
            <div className="bg-slate-800 border border-slate-700 rounded-lg shadow-lg flex flex-col h-[65vh]">
                <div ref={chatContainerRef} className="flex-1 p-6 space-y-6 overflow-y-auto">
                    {messages.map((msg, index) => (
                        <div key={index} className={`flex items-start gap-4 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                            {msg.role === 'model' && (
                                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-slate-600 flex items-center justify-center">
                                    <BriefcaseIcon className="w-5 h-5 text-slate-300" />
                                </div>
                            )}
                            <div className={`max-w-xl p-3 rounded-lg ${msg.role === 'user' ? 'bg-amber-800/60 text-amber-100' : 'bg-slate-700 text-slate-300'}`}>
                                <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                            </div>
                            {msg.role === 'user' && (
                                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-slate-600 flex items-center justify-center">
                                    <UserCircleIcon className="w-5 h-5 text-slate-300"/>
                                </div>
                            )}
                        </div>
                    ))}
                    {isLoading && (
                        <div className="flex items-start gap-4">
                            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-slate-600 flex items-center justify-center">
                                <BriefcaseIcon className="w-5 h-5 text-slate-300" />
                            </div>
                            <div className="max-w-xl p-3 rounded-lg bg-slate-700">
                                <LoadingSpinner />
                            </div>
                        </div>
                    )}
                </div>
                <div className="p-4 border-t border-slate-700">
                     {error && <p className="text-red-400 text-xs text-center mb-2">{error}</p>}
                    <div className="flex items-center gap-2">
                        <input
                            type="text"
                            value={currentMessage}
                            onChange={(e) => setCurrentMessage(e.target.value)}
                            placeholder="Ask your question..."
                            className="flex-grow p-3 bg-slate-900 border border-slate-600 rounded-md focus:ring-2 focus:ring-amber-400 focus:border-amber-400 transition-colors"
                            disabled={isLoading}
                            onKeyDown={(e) => e.key === 'Enter' && !isLoading && handleSendMessage()}
                        />
                        <button
                            onClick={handleSendMessage}
                            disabled={isLoading || !currentMessage.trim()}
                            className="p-3 bg-amber-600 text-white font-semibold rounded-md hover:bg-amber-700 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors flex-shrink-0"
                            aria-label="Send message"
                        >
                           <PaperAirplaneIcon />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    )
};

export default OralArgumentCoach;
