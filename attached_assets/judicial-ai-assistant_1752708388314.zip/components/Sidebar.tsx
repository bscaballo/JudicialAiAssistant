
import React from 'react';
import type { ActiveTab, User } from '../types';
import { TABS } from '../constants';
import { LogoutIcon } from './common/Icons';

interface SidebarProps {
    activeTab: ActiveTab;
    setActiveTab: (tab: ActiveTab) => void;
    currentUser: User;
    onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, currentUser, onLogout }) => {
    return (
        <aside className="w-64 bg-slate-800/50 border-r border-slate-700/50 p-4 flex flex-col flex-shrink-0">
            <div className="flex flex-col items-center mb-10">
                 <div className="w-20 h-20 bg-slate-700 rounded-full flex items-center justify-center border-2 border-amber-400">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-amber-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21v-2a6 6 0 00-12 0v2" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12a4 4 0 110-8 4 4 0 010 8z" />
                    </svg>
                 </div>
                <h1 className="text-xl font-serif font-bold text-center mt-4 text-white">Judicial AI</h1>
                <p className="text-sm text-slate-400 text-center break-all px-2">{currentUser.email}</p>
            </div>
            <nav className="flex flex-col space-y-2 flex-grow">
                {TABS.map((tab) => (
                    <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-all duration-200 ${
                            activeTab === tab.id
                                ? 'bg-amber-500/10 text-amber-300 shadow-inner'
                                : 'text-slate-300 hover:bg-slate-700/50 hover:text-white'
                        }`}
                    >
                        <span className={activeTab === tab.id ? 'text-amber-400' : 'text-slate-400'}>{tab.icon}</span>
                        <span className="font-medium text-sm">{tab.name}</span>
                    </button>
                ))}
            </nav>
            <div className="mt-auto">
                <button
                    onClick={onLogout}
                    className="flex w-full items-center space-x-3 px-4 py-3 rounded-lg text-left transition-all duration-200 text-slate-300 hover:bg-red-800/50 hover:text-white"
                >
                    <span className="text-slate-400"><LogoutIcon /></span>
                    <span className="font-medium text-sm">Logout</span>
                </button>
            </div>
        </aside>
    );
};

export default Sidebar;
