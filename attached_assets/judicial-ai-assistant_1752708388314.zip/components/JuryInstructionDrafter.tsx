
import React, { useState, useCallback } from 'react';
import { draftJuryInstructions } from '../services/geminiService';
import type { JuryInstructionDetails, User } from '../types';
import LoadingSpinner from './common/LoadingSpinner';
import ResultCard from './common/ResultCard';
import * as historyService from '../services/historyService';

interface JuryInstructionDrafterProps {
    currentUser: User | null;
}

const JuryInstructionDrafter: React.FC<JuryInstructionDrafterProps> = ({ currentUser }) => {
    const [details, setDetails] = useState<JuryInstructionDetails>({
        caseName: '',
        charges: '',
        specificPointsToCover: ''
    });
    const [isLoading, setIsLoading] = useState(false);
    const [result, setResult] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setDetails({ ...details, [e.target.name]: e.target.value });
    };

    const handleSubmit = useCallback(async () => {
        if (!details.caseName.trim() || !details.charges.trim() || !currentUser) {
            setError('Please fill in at least Case Name and Charges.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setResult(null);
        try {
            const instructions = await draftJuryInstructions(details);
            setResult(instructions);
            historyService.addHistoryItem(currentUser.id, {
                type: 'jury-instruction-drafter',
                input: { ...details },
                output: { instructions: instructions },
            });
        } catch (err: unknown) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, [details, currentUser]);
    
    const isFormIncomplete = !details.caseName || !details.charges;

    return (
        <div>
            <h2 className="text-3xl font-bold font-serif text-white">Jury Instruction Drafter</h2>
            <p className="mt-2 text-slate-400">Generate clear, unbiased jury instructions based on the case charges and legal standards.</p>

            <div className="mt-6 space-y-4">
                <input
                    type="text"
                    name="caseName"
                    value={details.caseName}
                    onChange={handleChange}
                    placeholder="Case Name (e.g., State v. Thompson)"
                    className="w-full p-3 bg-slate-800 border border-slate-700 rounded-md focus:ring-2 focus:ring-amber-400 focus:border-amber-400 transition-colors"
                    disabled={isLoading}
                />
                <textarea
                    name="charges"
                    value={details.charges}
                    onChange={handleChange}
                    placeholder="List the specific charges, one per line (e.g., 'First-degree murder', 'Tampering with evidence')"
                    className="w-full h-24 p-3 bg-slate-800 border border-slate-700 rounded-md focus:ring-2 focus:ring-amber-400 focus:border-amber-400 transition-colors"
                    disabled={isLoading}
                />
                <textarea
                    name="specificPointsToCover"
                    value={details.specificPointsToCover}
                    onChange={handleChange}
                    placeholder="(Optional) Note any specific legal principles, definitions, or instructions to include. e.g., 'Define reasonable doubt as per state law.'"
                    className="w-full h-24 p-3 bg-slate-800 border border-slate-700 rounded-md focus:ring-2 focus:ring-amber-400 focus:border-amber-400 transition-colors"
                    disabled={isLoading}
                />
            </div>

            <div className="mt-4">
                <button
                    onClick={handleSubmit}
                    disabled={isLoading || isFormIncomplete}
                    className="px-6 py-2 bg-amber-600 text-white font-semibold rounded-md hover:bg-amber-700 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
                >
                    {isLoading ? 'Generating...' : 'Generate Instructions'}
                </button>
            </div>

            {isLoading && <LoadingSpinner />}
            {error && <div className="mt-6 p-4 bg-red-900/50 border border-red-700 text-red-300 rounded-md">{error}</div>}
            {result && (
                <ResultCard title="Draft Jury Instructions">
                    <pre className="font-sans text-sm">{result}</pre>
                </ResultCard>
            )}
        </div>
    );
};

export default JuryInstructionDrafter;
