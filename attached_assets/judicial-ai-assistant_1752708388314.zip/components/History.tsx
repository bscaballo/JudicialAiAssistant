
import React, { useState, useEffect } from 'react';
import type { User, HistoryItem, DocketItem, HistoricalCase, DraftedOrder } from '../types';
import * as historyService from '../services/historyService';
import { TABS } from '../constants';
import FormattedOrder from './common/FormattedOrder';

interface HistoryProps {
    currentUser: User | null;
}

const History: React.FC<HistoryProps> = ({ currentUser }) => {
    const [history, setHistory] = useState<HistoryItem[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (currentUser) {
            setLoading(true);
            const userHistory = historyService.getHistory(currentUser.id);
            setHistory(userHistory);
            setLoading(false);
        }
    }, [currentUser]);
    
    const getTabInfo = (type: HistoryItem['type']) => {
        return TABS.find(tab => tab.id === type) || { name: 'Unknown Activity', icon: '?' };
    };

    const renderData = (value: any, context: { type: HistoryItem['type'], section: 'input' | 'output', key: string }) => {
        // Special renderers for complex array outputs
        if (context.section === 'output') {
             if (context.type === 'order-drafter' && context.key === 'draftedOrder' && typeof value === 'object' && value !== null && !Array.isArray(value)) {
                return <FormattedOrder order={value as DraftedOrder} />;
            }
            if (context.type === 'legal-research' && context.key === 'sources' && Array.isArray(value)) {
                return (
                    <div className="bg-slate-900 border border-slate-700 rounded-md p-3">
                        <ul className="list-disc list-inside space-y-1 text-sm">
                            {(value as string[]).map((url, index) => (
                                <li key={index}>
                                    <a href={url} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline break-all">{url}</a>
                                </li>
                            ))}
                        </ul>
                    </div>
                );
            }
            
            if (context.type === 'daily-docket' && context.key === 'docket' && Array.isArray(value) && value.length > 0) {
                return (
                    <div className="space-y-3">
                        {(value as DocketItem[]).map((item, index) => (
                            <div key={index} className="p-3 bg-slate-900 border border-slate-700 rounded-md">
                                <h4 className="font-semibold text-amber-200">{item.caseName}</h4>
                                <p className="mt-1 text-sm text-slate-300 italic">"{item.summary}"</p>
                                <div className="mt-2">
                                    <h5 className="font-medium text-slate-200 text-xs">Key Issues:</h5>
                                    <ul className="list-disc list-inside mt-1 text-sm text-slate-300 space-y-1">
                                        {item.keyIssues.map((issue, issueIndex) => (
                                            <li key={issueIndex}>{issue}</li>
                                        ))}
                                    </ul>
                                </div>
                            </div>
                        ))}
                    </div>
                );
            }

            if (context.type === 'case-law-explorer' && context.key === 'results' && Array.isArray(value) && value.length > 0) {
                 return (
                    <div className="space-y-3">
                        {(value as HistoricalCase[]).map((item, index) => (
                            <div key={index} className="p-3 bg-slate-900 border border-slate-700 rounded-md">
                                <h4 className="font-semibold text-amber-200">{item.caseName}</h4>
                                <p className="text-xs text-slate-400 italic">{item.citation} ({item.year}) - {item.court}</p>
                                <div className="mt-2 space-y-1">
                                    <div>
                                        <h5 className="font-medium text-slate-200 text-xs">Summary:</h5>
                                        <p className="text-sm text-slate-300">{item.summary}</p>
                                    </div>
                                    <div>
                                        <h5 className="font-medium text-slate-200 text-xs">Key Principle:</h5>
                                        <p className="text-sm text-slate-300">{item.keyPrinciple}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                );
            }
        }

        // Generic renderer for simple objects (non-array)
        if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
            return (
                 <div className="bg-slate-900 border border-slate-700 rounded-md p-3 space-y-2">
                    {Object.entries(value).map(([key, val]) => (
                        <div key={key} className="text-sm">
                            <p className="font-semibold text-slate-400 capitalize">{key.replace(/([A-Z])/g, ' $1')}:</p>
                            <pre className="text-slate-300 pl-2 whitespace-pre-wrap break-words font-sans">{String(val)}</pre>
                        </div>
                    ))}
                </div>
            );
        }

        // Default renderer for strings and other primitive types
        return (
            <div className="bg-slate-900 border border-slate-700 rounded-md">
                <pre className="p-3 text-sm text-slate-300 whitespace-pre-wrap break-words font-sans">
                    {String(value)}
                </pre>
            </div>
        );
    };

    const ChevronIcon = () => (
        <svg className="w-5 h-5 text-slate-400 transition-transform transform group-open:rotate-90" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="2.5" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
        </svg>
    );

    return (
        <div>
            <h2 className="text-3xl font-bold font-serif text-white">Activity History</h2>
            <p className="mt-2 text-slate-400">A log of your activity. All items are stored locally in your browser.</p>
            
            <div className="mt-8 space-y-4">
                {loading && <p>Loading history...</p>}
                {!loading && history.length === 0 && (
                    <div className="text-center py-12 px-6 bg-slate-800/50 border border-slate-700 rounded-lg">
                        <h3 className="text-xl font-semibold text-slate-300">No Activity Yet</h3>
                        <p className="text-slate-400 mt-2">Your actions will be recorded here for future reference.</p>
                    </div>
                )}
                {!loading && history.map((item) => {
                    const tabInfo = getTabInfo(item.type);
                    return (
                        <details key={item.id} className="group bg-slate-800 border border-slate-700 rounded-lg shadow-md transition-all duration-300 open:ring-2 open:ring-amber-400">
                            <summary className="list-none flex justify-between items-center p-4 cursor-pointer hover:bg-slate-700/50 transition-colors rounded-t-lg group-open:bg-slate-700/30 group-open:rounded-b-none">
                                <div className="flex items-center gap-4">
                                     <span className="flex-shrink-0 h-10 w-10 rounded-full bg-slate-700 flex items-center justify-center text-amber-400 border border-slate-600">{tabInfo.icon}</span>
                                     <div>
                                        <h4 className="font-semibold text-lg text-amber-300">{tabInfo.name}</h4>
                                        <p className="text-xs text-slate-400">{new Date(item.timestamp).toLocaleString()}</p>
                                     </div>
                                </div>
                                 <ChevronIcon />
                            </summary>
                            <div className="p-6 border-t border-slate-700 bg-black/10 grid md:grid-cols-2 gap-x-8 gap-y-6 rounded-b-lg">
                                <div className="space-y-4">
                                    <h5 className="font-bold text-slate-200 border-b border-slate-600 pb-2">Input</h5>
                                    {Object.entries(item.input).map(([key, value]) => (
                                        <div key={key}>
                                            <p className="font-semibold text-slate-400 capitalize text-sm mb-2">{key.replace(/([A-Z])/g, ' $1')}:</p>
                                            {renderData(value, { type: item.type, section: 'input', key })}
                                        </div>
                                    ))}
                                </div>
                                <div className="space-y-4">
                                    <h5 className="font-bold text-slate-200 border-b border-slate-600 pb-2">Output</h5>
                                     {Object.entries(item.output).map(([key, value]) => (
                                        <div key={key}>
                                            <p className="font-semibold text-slate-400 capitalize text-sm mb-2">{key.replace(/([A-Z])/g, ' $1')}:</p>
                                            {renderData(value, { type: item.type, section: 'output', key })}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </details>
                    );
                })}
            </div>
        </div>
    );
};

export default History;