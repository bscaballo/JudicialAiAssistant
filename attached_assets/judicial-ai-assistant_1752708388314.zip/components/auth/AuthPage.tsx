import React, { useState } from 'react';
import type { User } from '../../types';
import * as authService from '../../services/authService';

interface AuthPageProps {
    onLoginSuccess: (user: User) => void;
}

const AuthPage: React.FC<AuthPageProps> = ({ onLoginSuccess }) => {
    const [isLoginMode, setIsLoginMode] = useState(true);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        setIsLoading(true);

        try {
            if (isLoginMode) {
                const user = await authService.login(email, password);
                onLoginSuccess(user);
            } else {
                await authService.signUp(email, password);
                const user = await authService.login(email, password);
                onLoginSuccess(user);
            }
        } catch (err: any) {
            setError(err.message || 'An unexpected error occurred.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="flex min-h-screen flex-col justify-center items-center bg-slate-900 p-4">
            <div className="w-full max-w-md">
                <div className="flex flex-col items-center mb-6">
                     <div className="w-24 h-24 bg-slate-800 rounded-full flex items-center justify-center border-2 border-amber-400">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-amber-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21v-2a6 6 0 00-12 0v2" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12a4 4 0 110-8 4 4 0 010 8z" />
                        </svg>
                     </div>
                    <h1 className="text-3xl font-serif font-bold text-center mt-4 text-white">Judicial AI Assistant</h1>
                    <p className="text-md text-slate-400 text-center">For Hon. Lori Gibson Willard</p>
                </div>
                <div className="bg-slate-800/50 border border-slate-700/50 rounded-lg shadow-xl p-8">
                    <h2 className="text-2xl font-bold text-center text-amber-300 mb-6">{isLoginMode ? 'Login' : 'Create Account'}</h2>
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div>
                            <label htmlFor="email" className="block text-sm font-medium text-slate-300">Email Address</label>
                            <input
                                id="email"
                                name="email"
                                type="email"
                                autoComplete="email"
                                required
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="mt-1 block w-full p-3 bg-slate-800 border border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-white"
                            />
                        </div>
                        <div>
                            <label htmlFor="password"className="block text-sm font-medium text-slate-300">Password</label>
                            <input
                                id="password"
                                name="password"
                                type="password"
                                autoComplete={isLoginMode ? 'current-password' : 'new-password'}
                                required
                                minLength={6}
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="mt-1 block w-full p-3 bg-slate-800 border border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-white"
                            />
                        </div>
                        {error && <p className="text-sm text-red-400">{error}</p>}
                        <div>
                            <button
                                type="submit"
                                disabled={isLoading}
                                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-amber-600 hover:bg-amber-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-amber-500 disabled:bg-slate-600"
                            >
                                {isLoading ? 'Processing...' : (isLoginMode ? 'Log In' : 'Sign Up')}
                            </button>
                        </div>
                    </form>
                    <div className="mt-6 text-center">
                        <button onClick={() => { setIsLoginMode(!isLoginMode); setError(null);}} className="text-sm text-amber-400 hover:text-amber-300 hover:underline">
                            {isLoginMode ? 'Need an account? Sign up' : 'Already have an account? Log in'}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AuthPage;