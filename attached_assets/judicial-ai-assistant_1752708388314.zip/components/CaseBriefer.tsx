
import React, { useState, useCallback } from 'react';
import { summarizeText } from '../services/geminiService';
import LoadingSpinner from './common/LoadingSpinner';
import ResultCard from './common/ResultCard';
import * as historyService from '../services/historyService';
import type { User } from '../types';

interface CaseBrieferProps {
    currentUser: User | null;
}

const CaseBriefer: React.FC<CaseBrieferProps> = ({ currentUser }) => {
    const [inputText, setInputText] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [result, setResult] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    const handleSubmit = useCallback(async () => {
        if (!inputText.trim() || !currentUser) {
            setError('Please enter some text to summarize.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setResult(null);
        try {
            const summary = await summarizeText(inputText);
            setResult(summary);
            historyService.addHistoryItem(currentUser.id, {
                type: 'case-briefer',
                input: { documentText: inputText.substring(0, 500) + (inputText.length > 500 ? '...' : '') },
                output: { summary: summary },
            });
        } catch (err: unknown) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, [inputText, currentUser]);

    return (
        <div>
            <h2 className="text-3xl font-bold font-serif text-white">Case Briefer</h2>
            <p className="mt-2 text-slate-400">Paste the full text of a motion, pleading, or transcript below to receive a concise summary.</p>

            <div className="mt-6">
                <textarea
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="Paste legal document text here..."
                    className="w-full h-64 p-4 bg-slate-800 border border-slate-700 rounded-md focus:ring-2 focus:ring-amber-400 focus:border-amber-400 transition-colors"
                    disabled={isLoading}
                />
            </div>

            <div className="mt-4">
                <button
                    onClick={handleSubmit}
                    disabled={isLoading || !inputText}
                    className="px-6 py-2 bg-amber-600 text-white font-semibold rounded-md hover:bg-amber-700 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
                >
                    {isLoading ? 'Generating...' : 'Generate Brief'}
                </button>
            </div>

            {isLoading && <LoadingSpinner />}
            {error && <div className="mt-6 p-4 bg-red-900/50 border border-red-700 text-red-300 rounded-md">{error}</div>}
            {result && (
                <ResultCard title="Generated Case Brief">
                    <p>{result}</p>
                </ResultCard>
            )}
        </div>
    );
};

export default CaseBriefer;
