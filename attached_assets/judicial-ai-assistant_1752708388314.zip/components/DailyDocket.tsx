
import React, { useState, useCallback } from 'react';
import { generateDocket } from '../services/geminiService';
import type { DocketItem, User } from '../types';
import LoadingSpinner from './common/LoadingSpinner';
import ResultCard from './common/ResultCard';
import * as historyService from '../services/historyService';

interface DailyDocketProps {
    currentUser: User | null;
}

const DailyDocket: React.FC<DailyDocketProps> = ({ currentUser }) => {
    const [caseList, setCaseList] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [result, setResult] = useState<DocketItem[] | null>(null);
    const [error, setError] = useState<string | null>(null);

    const handleSubmit = useCallback(async () => {
        if (!caseList.trim() || !currentUser) {
            setError('Please enter a list of cases.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setResult(null);
        try {
            const docket = await generateDocket(caseList);
            setResult(docket);
            historyService.addHistoryItem(currentUser.id, {
                type: 'daily-docket',
                input: { caseList: caseList },
                output: { docket: docket },
            });
        } catch (err: unknown) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, [caseList, currentUser]);

    return (
        <div>
            <h2 className="text-3xl font-bold font-serif text-white">Daily Docket Generator</h2>
            <p className="mt-2 text-slate-400">Enter today's cases, one per line, to generate a structured docket with summaries and key issues.</p>

            <div className="mt-6">
                <textarea
                    value={caseList}
                    onChange={(e) => setCaseList(e.target.value)}
                    placeholder="e.g.,&#10;9:00 AM - Johnson v. Dept. of Transportation - Motion Hearing&#10;10:30 AM - Estate of Garcia - Status Conference&#10;1:30 PM - State v. Michaels - Sentencing"
                    className="w-full h-48 p-4 bg-slate-800 border border-slate-700 rounded-md focus:ring-2 focus:ring-amber-400 focus:border-amber-400 transition-colors"
                    disabled={isLoading}
                />
            </div>

            <div className="mt-4">
                <button
                    onClick={handleSubmit}
                    disabled={isLoading || !caseList}
                    className="px-6 py-2 bg-amber-600 text-white font-semibold rounded-md hover:bg-amber-700 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
                >
                    {isLoading ? 'Generating...' : 'Generate Docket'}
                </button>
            </div>

            {isLoading && <LoadingSpinner />}
            {error && <div className="mt-6 p-4 bg-red-900/50 border border-red-700 text-red-300 rounded-md">{error}</div>}
            {result && (
                <ResultCard title="Generated Daily Docket">
                    <div className="space-y-6">
                        {result.map((item, index) => (
                            <div key={index} className="p-4 bg-slate-700/50 rounded-lg border border-slate-600">
                                <h4 className="font-bold text-lg text-amber-200">{item.caseName}</h4>
                                <p className="mt-1 text-slate-300 italic">"{item.summary}"</p>
                                <div className="mt-3">
                                    <h5 className="font-semibold text-slate-200">Key Issues:</h5>
                                    <ul className="list-disc list-inside mt-1 text-slate-300 space-y-1">
                                        {item.keyIssues.map((issue, issueIndex) => (
                                            <li key={issueIndex}>{issue}</li>
                                        ))}
                                    </ul>
                                </div>
                            </div>
                        ))}
                    </div>
                </ResultCard>
            )}
        </div>
    );
};

export default DailyDocket;
