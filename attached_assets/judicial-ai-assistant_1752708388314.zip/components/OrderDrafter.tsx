
import React, { useState, useCallback } from 'react';
import { draftOrder } from '../services/geminiService';
import type { OrderDetails, User, DraftedOrder } from '../types';
import LoadingSpinner from './common/LoadingSpinner';
import ResultCard from './common/ResultCard';
import * as historyService from '../services/historyService';
import FormattedOrder from './common/FormattedOrder';

interface OrderDrafterProps {
    currentUser: User | null;
}

const OrderDrafter: React.FC<OrderDrafterProps> = ({ currentUser }) => {
    const [details, setDetails] = useState<OrderDetails>({
        caseName: '',
        caseNumber: '',
        rulingDetails: ''
    });
    const [isLoading, setIsLoading] = useState(false);
    const [result, setResult] = useState<DraftedOrder | null>(null);
    const [error, setError] = useState<string | null>(null);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setDetails({ ...details, [e.target.name]: e.target.value });
    };

    const handleSubmit = useCallback(async () => {
        if (!details.caseName.trim() || !details.caseNumber.trim() || !details.rulingDetails.trim() || !currentUser) {
            setError('Please fill in all fields.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setResult(null);
        try {
            const order = await draftOrder(details);
            setResult(order);
             historyService.addHistoryItem(currentUser.id, {
                type: 'order-drafter',
                input: { ...details },
                output: { draftedOrder: order },
            });
        } catch (err: unknown) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, [details, currentUser]);
    
    const isFormIncomplete = !details.caseName || !details.caseNumber || !details.rulingDetails;

    return (
        <div>
            <h2 className="text-3xl font-bold font-serif text-white">Court Order Drafter</h2>
            <p className="mt-2 text-slate-400">Enter the key details below to generate a draft court order.</p>

            <div className="mt-6 space-y-4">
                <input
                    type="text"
                    name="caseName"
                    value={details.caseName}
                    onChange={handleChange}
                    placeholder="Case Name / Style (e.g., Smith v. Jones)"
                    className="w-full p-3 bg-slate-800 border border-slate-700 rounded-md focus:ring-2 focus:ring-amber-400 focus:border-amber-400 transition-colors"
                    disabled={isLoading}
                />
                <input
                    type="text"
                    name="caseNumber"
                    value={details.caseNumber}
                    onChange={handleChange}
                    placeholder="Case Number (e.g., CV-2024-123)"
                    className="w-full p-3 bg-slate-800 border border-slate-700 rounded-md focus:ring-2 focus:ring-amber-400 focus:border-amber-400 transition-colors"
                    disabled={isLoading}
                />
                <textarea
                    name="rulingDetails"
                    value={details.rulingDetails}
                    onChange={handleChange}
                    placeholder="Describe the ruling. For example: 'Plaintiff's motion for summary judgment is granted. Defendant's cross-motion is denied. The court finds no genuine issue of material fact...'"
                    className="w-full h-40 p-3 bg-slate-800 border border-slate-700 rounded-md focus:ring-2 focus:ring-amber-400 focus:border-amber-400 transition-colors"
                    disabled={isLoading}
                />
            </div>

            <div className="mt-4">
                <button
                    onClick={handleSubmit}
                    disabled={isLoading || isFormIncomplete}
                    className="px-6 py-2 bg-amber-600 text-white font-semibold rounded-md hover:bg-amber-700 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
                >
                    {isLoading ? 'Drafting...' : 'Draft Order'}
                </button>
            </div>

            {isLoading && <LoadingSpinner />}
            {error && <div className="mt-6 p-4 bg-red-900/50 border border-red-700 text-red-300 rounded-md">{error}</div>}
            {result && (
                <ResultCard title="Draft Court Order">
                    <FormattedOrder order={result} />
                </ResultCard>
            )}
        </div>
    );
};

export default OrderDrafter;