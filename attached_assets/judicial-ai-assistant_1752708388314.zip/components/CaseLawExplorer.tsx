import React, { useState, useCallback } from 'react';
import { searchCaseLaw } from '../services/geminiService';
import type { HistoricalCase, User } from '../types';
import LoadingSpinner from './common/LoadingSpinner';
import ResultCard from './common/ResultCard';
import * as historyService from '../services/historyService';

interface CaseLawExplorerProps {
    currentUser: User | null;
}

const CaseLawExplorer: React.FC<CaseLawExplorerProps> = ({ currentUser }) => {
    const [query, setQuery] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [result, setResult] = useState<HistoricalCase[] | null>(null);
    const [error, setError] = useState<string | null>(null);

    const handleSubmit = useCallback(async () => {
        if (!query.trim() || !currentUser) {
            setError('Please enter a research query.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setResult(null);
        try {
            const response = await searchCaseLaw(query);
            setResult(response);
            historyService.addHistoryItem(currentUser.id, {
                type: 'case-law-explorer',
                input: { query: query },
                output: { results: response },
            });
        } catch (err: unknown) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, [query, currentUser]);

    return (
        <div>
            <h2 className="text-3xl font-bold font-serif text-white">Case Law Explorer</h2>
            <p className="mt-2 text-slate-400">
                Search for relevant precedents and legal principles in the historical U.S. case law archive (pre-2018), sourced from the <a href="https://huggingface.co/datasets/common-pile/caselaw_access_project" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">Caselaw Access Project</a>.
            </p>

            <div className="mt-6 flex gap-4">
                <input
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="e.g., 'admissibility of hearsay evidence in 19th century'"
                    className="flex-grow p-3 bg-slate-800 border border-slate-700 rounded-md focus:ring-2 focus:ring-amber-400 focus:border-amber-400 transition-colors"
                    disabled={isLoading}
                    onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
                />
                <button
                    onClick={handleSubmit}
                    disabled={isLoading || !query}
                    className="px-6 py-2 bg-amber-600 text-white font-semibold rounded-md hover:bg-amber-700 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
                >
                    {isLoading ? 'Searching...' : 'Search Archive'}
                </button>
            </div>

            {isLoading && <LoadingSpinner />}
            {error && <div className="mt-6 p-4 bg-red-900/50 border border-red-700 text-red-300 rounded-md">{error}</div>}
            
            {result && result.length > 0 && (
                <ResultCard title="Historical Case Law Results">
                    <div className="space-y-8">
                        {result.map((item, index) => (
                            <div key={index} className="p-4 bg-slate-700/50 rounded-lg border border-slate-600">
                                <h4 className="font-bold text-lg text-amber-200">{item.caseName}</h4>
                                <p className="text-sm text-slate-400 italic">{item.citation} ({item.year}) - {item.court}</p>
                                <div className="mt-3 space-y-2">
                                    <div>
                                        <h5 className="font-semibold text-slate-200">Summary:</h5>
                                        <p className="text-slate-300">{item.summary}</p>
                                    </div>
                                    <div>
                                        <h5 className="font-semibold text-slate-200">Key Principle:</h5>
                                        <p className="text-slate-300">{item.keyPrinciple}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </ResultCard>
            )}

             {result && result.length === 0 && (
                <ResultCard title="Historical Case Law Results">
                   <p>No relevant cases found in the historical archive for your query.</p>
                </ResultCard>
            )}
        </div>
    );
};

export default CaseLawExplorer;