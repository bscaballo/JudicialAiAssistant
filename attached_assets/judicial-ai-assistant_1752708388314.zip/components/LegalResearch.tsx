
import React, { useState, useCallback } from 'react';
import { researchTopic } from '../services/geminiService';
import type { GroundingChunk, User } from '../types';
import LoadingSpinner from './common/LoadingSpinner';
import ResultCard from './common/ResultCard';
import * as historyService from '../services/historyService';

interface LegalResearchProps {
    currentUser: User | null;
}

const LegalResearch: React.FC<LegalResearchProps> = ({ currentUser }) => {
    const [query, setQuery] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [result, setResult] = useState<{ text: string; sources: GroundingChunk[] } | null>(null);
    const [error, setError] = useState<string | null>(null);

    const handleSubmit = useCallback(async () => {
        if (!query.trim() || !currentUser) {
            setError('Please enter a research query.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setResult(null);
        try {
            const response = await researchTopic(query);
            setResult(response);
            historyService.addHistoryItem(currentUser.id, {
                type: 'legal-research',
                input: { query: query },
                output: { resultText: response.text, sources: response.sources.map(s => s.web.uri) },
            });
        } catch (err: unknown) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, [query, currentUser]);

    return (
        <div>
            <h2 className="text-3xl font-bold font-serif text-white">Legal Research Assistant</h2>
            <p className="mt-2 text-slate-400">Ask a question to search relevant statutes, case law, and legal precedents. Results are grounded with Google Search for up-to-date information.</p>

            <div className="mt-6 flex gap-4">
                <input
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="e.g., 'Standard for summary judgment in New Mexico'"
                    className="flex-grow p-3 bg-slate-800 border border-slate-700 rounded-md focus:ring-2 focus:ring-amber-400 focus:border-amber-400 transition-colors"
                    disabled={isLoading}
                    onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
                />
                <button
                    onClick={handleSubmit}
                    disabled={isLoading || !query}
                    className="px-6 py-2 bg-amber-600 text-white font-semibold rounded-md hover:bg-amber-700 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
                >
                    {isLoading ? 'Searching...' : 'Search'}
                </button>
            </div>

            {isLoading && <LoadingSpinner />}
            {error && <div className="mt-6 p-4 bg-red-900/50 border border-red-700 text-red-300 rounded-md">{error}</div>}
            {result && (
                <ResultCard title="Research Results">
                    <div>
                        <p className="mb-6">{result.text}</p>
                        {result.sources.length > 0 && (
                             <div>
                                <h4 className="text-lg font-bold font-serif text-amber-200 border-t border-slate-600 pt-4 mt-4">Sources</h4>
                                <ul className="list-disc pl-5 mt-2 space-y-2">
                                    {result.sources.map((source, index) => (
                                        <li key={index}>
                                            <a href={source.web.uri} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">
                                                {source.web.title || source.web.uri}
                                            </a>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                    </div>
                </ResultCard>
            )}
        </div>
    );
};

export default LegalResearch;
