
import type { User } from '../types';

const USERS_KEY = 'judicial_ai_users';
const SESSION_KEY = 'judicial_ai_session';

// In a real app, never store passwords in plaintext. This is for demonstration purposes only.
// Hashing with a salt should be done on a secure backend.

const getUsers = (): Record<string, string> => {
    try {
        const users = localStorage.getItem(USERS_KEY);
        return users ? JSON.parse(users) : {};
    } catch (e) {
        return {};
    }
};

const saveUsers = (users: Record<string, string>) => {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
};

export const signUp = (email: string, password: string): Promise<User> => {
    return new Promise((resolve, reject) => {
        const users = getUsers();
        if (users[email]) {
            return reject(new Error('User with this email already exists.'));
        }
        users[email] = password; // Storing password directly. NOT FOR PRODUCTION.
        saveUsers(users);
        const newUser: User = { id: email, email };
        resolve(newUser);
    });
};

export const login = (email: string, password: string): Promise<User> => {
    return new Promise((resolve, reject) => {
        const users = getUsers();
        if (!users[email] || users[email] !== password) {
            return reject(new Error('Invalid email or password.'));
        }
        const user: User = { id: email, email };
        sessionStorage.setItem(SESSION_KEY, JSON.stringify(user));
        resolve(user);
    });
};

export const logout = (): void => {
    sessionStorage.removeItem(SESSION_KEY);
};

export const getCurrentUser = (): User | null => {
    try {
        const userStr = sessionStorage.getItem(SESSION_KEY);
        return userStr ? JSON.parse(userStr) : null;
    } catch (e) {
        return null;
    }
};
