import { GoogleGenAI, Type, GenerateContentResponse, Chat } from "@google/genai";
import type { OrderDetails, GroundingChunk, DocketItem, JuryInstructionDetails, HistoricalCase, DraftedOrder } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const summarizeText = async (text: string): Promise<string> => {
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Please provide a concise legal brief of the following text. Identify the parties involved, the core legal arguments, the relief sought, and any key evidence mentioned. The summary should be clear, objective, and structured for a judge's review. \n\nTEXT: """${text}"""`,
             config: {
                systemInstruction: "You are an expert judicial clerk AI assistant. Your task is to summarize legal documents with extreme accuracy and neutrality.",
            }
        });
        return response.text;
    } catch (error) {
        console.error("Error summarizing text:", error);
        throw new Error("Failed to generate summary. Please check the console for details.");
    }
};

export const researchTopic = async (topic: string): Promise<{ text: string; sources: GroundingChunk[] }> => {
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: topic,
            config: {
                systemInstruction: "You are a legal research assistant for a district judge. Provide comprehensive, accurate, and neutral answers to legal questions. Cite relevant statutes and case law.",
                tools: [{ googleSearch: {} }],
            },
        });

        const text = response.text;
        const groundingMetadata = response.candidates?.[0]?.groundingMetadata;
        const sources = groundingMetadata?.groundingChunks?.filter(
            (chunk): chunk is GroundingChunk => chunk.web !== undefined
        ) || [];

        return { text, sources };
    } catch (error) {
        console.error("Error with legal research:", error);
        throw new Error("Failed to perform legal research. Please check the console for details.");
    }
};

export const analyzeImage = async (imageBase64: string, mimeType: string, prompt: string): Promise<string> => {
    try {
        const imagePart = {
            inlineData: {
                mimeType,
                data: imageBase64,
            },
        };
        const textPart = { text: prompt };
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts: [imagePart, textPart] },
            config: {
                systemInstruction: "You are an expert forensic analyst AI. Your analysis must be objective, factual, and strictly based on the provided image. Do not make assumptions or inferences beyond what is visually present."
            }
        });
        return response.text;
    } catch (error) {
        console.error("Error analyzing image:", error);
        throw new Error("Failed to analyze the image. Please check the console for details.");
    }
};

export const draftOrder = async (details: OrderDetails): Promise<DraftedOrder> => {
    const { caseName, caseNumber, rulingDetails } = details;
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Draft a formal court order for the following case:
            - Case Name/Style: ${caseName}
            - Case Number: ${caseNumber}
            - Details of the Ruling: ${rulingDetails}`,
            config: {
                systemInstruction: "You are a judicial AI trained to draft formal, well-structured court orders. The language must be precise, authoritative, and follow standard legal conventions for the State of New Mexico.",
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        caseStyle: { type: Type.STRING, description: "The full style of the case, e.g., 'Plaintiff v. Defendant'." },
                        caseNumber: { type: Type.STRING, description: "The official court case number." },
                        courtName: { type: Type.STRING, description: "The name of the court, e.g., 'Twelfth Judicial District Court'." },
                        division: {type: Type.STRING, description: "The division of the court, e.g., 'Division II'."},
                        judgeName: { type: Type.STRING, description: "The presiding judge's name, e.g., 'Hon. Lori Gibson Willard'."},
                        orderTitle: { type: Type.STRING, description: "The title of the order, e.g., 'ORDER ON PLAINTIFF'S MOTION TO COMPEL'." },
                        introduction: { type: Type.STRING, description: "Introductory paragraph stating the matter before the court." },
                        findingsOfFact: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of factual findings supporting the decision."},
                        conclusionsOfLaw: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of legal conclusions based on the facts and relevant law."},
                        orderClause: { type: Type.STRING, description: "The final decretal paragraph, beginning with 'IT IS THEREFORE ORDERED, ADJUDGED, AND DECREED that...'"},
                        signatureLine: {type: Type.STRING, description: "A placeholder for the judge's signature, e.g., '____________________'."}
                    },
                     propertyOrdering: ["caseStyle", "caseNumber", "courtName", "division", "judgeName", "orderTitle", "introduction", "findingsOfFact", "conclusionsOfLaw", "orderClause", "signatureLine"]
                }
            }
        });

        const jsonText = response.text.trim();
        const draftedOrder: DraftedOrder = JSON.parse(jsonText);
        return draftedOrder;

    } catch (error) {
        console.error("Error drafting order:", error);
        throw new Error("Failed to draft the order. The AI may have returned an unexpected format.");
    }
};

export const draftJuryInstructions = async (details: JuryInstructionDetails): Promise<string> => {
    const { caseName, charges, specificPointsToCover } = details;
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Generate a complete set of jury instructions for a criminal case.
            - Case Name: ${caseName}
            - Charges: ${charges}
            - Specific Points to Cover: ${specificPointsToCover}`,
            config: {
                systemInstruction: "You are a judicial AI trained to draft clear, neutral, and legally sound jury instructions. The instructions must be easy for a layperson to understand, well-structured, and must conform to standard legal principles (e.g., presumption of innocence, burden of proof).",
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        caseName: { type: Type.STRING },
                        courtName: { type: Type.STRING, description: "e.g., 'IN THE TWELFTH JUDICIAL DISTRICT COURT'" },
                        title: { type: Type.STRING, description: "e.g., 'JURY INSTRUCTIONS'" },
                        introduction: { type: Type.STRING, description: "An opening statement to the jury explaining their role." },
                        generalInstructions: {
                            type: Type.ARRAY,
                            description: "Standard instructions applicable to all cases.",
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    title: { type: Type.STRING, description: "Title of the instruction, e.g., 'Burden of Proof'." },
                                    instruction: { type: Type.STRING, description: "The text of the instruction." }
                                }
                            }
                        },
                        chargeInstructions: {
                            type: Type.ARRAY,
                            description: "Instructions specific to each charge in the case.",
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    charge: { type: Type.STRING, description: "The specific criminal charge." },
                                    elements: { type: Type.ARRAY, items: { type: Type.STRING }, description: "The legal elements the state must prove for this charge." },
                                    instruction: { type: Type.STRING, description: "The full instruction text for the charge." }
                                }
                            }
                        },
                        concludingInstruction: { type: Type.STRING, description: "Final instructions on deliberation and reaching a verdict." }
                    }
                }
            }
        });

        const json = JSON.parse(response.text);

        let formattedText = `
${json.courtName.toUpperCase()}
COUNTY OF [Specify County], STATE OF NEW MEXICO

---

**${json.caseName}**

---

### **${json.title}**

${json.introduction}

---

`;

        json.generalInstructions.forEach((item: { title: string, instruction: string }, index: number) => {
            formattedText += `**INSTRUCTION NO. ${index + 1}: ${item.title.toUpperCase()}**\n\n${item.instruction}\n\n---\n\n`;
        });
        
        const generalCount = json.generalInstructions.length;
        json.chargeInstructions.forEach((item: { charge: string, elements: string[], instruction: string }, index: number) => {
            formattedText += `**INSTRUCTION NO. ${generalCount + index + 1}: ${item.charge.toUpperCase()}**\n\n`;
            if (item.elements && item.elements.length > 0) {
                 formattedText += `To find the defendant guilty of ${item.charge}, the state must prove each of the following elements beyond a reasonable doubt:\n`;
                 item.elements.forEach((el, elIndex) => {
                    formattedText += `${elIndex + 1}. ${el}\n`;
                 });
                 formattedText += `\n`;
            }
            formattedText += `${item.instruction}\n\n---\n\n`;
        });

        const totalCount = generalCount + json.chargeInstructions.length;
        formattedText += `**INSTRUCTION NO. ${totalCount + 1}: CONCLUDING INSTRUCTIONS**\n\n${json.concludingInstruction}`;

        return formattedText.trim();
    } catch (error) {
        console.error("Error drafting jury instructions:", error);
        throw new Error("Failed to draft instructions. The AI may have returned an unexpected format.");
    }
};

export const generateDocket = async (caseList: string): Promise<DocketItem[]> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Based on the following list of cases, generate a structured daily docket. For each case, provide a one-sentence summary and list the key issues to be addressed. Cases: """${caseList}"""`,
            config: {
                systemInstruction: "You are a judicial assistant AI. Your task is to create a clear and structured daily court docket from a list of cases.",
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            caseName: { type: Type.STRING, description: "The name of the case." },
                            summary: { type: Type.STRING, description: "A concise, one-sentence summary of the case hearing." },
                            keyIssues: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of key issues to be decided." }
                        },
                        required: ["caseName", "summary", "keyIssues"]
                    }
                }
            }
        });
        
        const jsonText = response.text.trim();
        const docketItems: DocketItem[] = JSON.parse(jsonText);
        return docketItems;

    } catch (error) {
        console.error("Error generating docket:", error);
        throw new Error("Failed to generate the docket. Please ensure the input format is correct.");
    }
};

export const searchCaseLaw = async (query: string): Promise<HistoricalCase[]> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Search for historical U.S. case law relevant to the following query: "${query}"`,
            config: {
                systemInstruction: "You are a legal historian AI with access to the Caselaw Access Project dataset, which contains all U.S. case law up to 2018. Your task is to find relevant historical cases for the user's query. For each case you find, provide the case name, full citation, year, court, a concise summary, and the key legal principle established. Do not use external search tools; rely solely on your knowledge of historical case law.",
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            caseName: { type: Type.STRING, description: "The name of the case (e.g., 'Marbury v. Madison')." },
                            citation: { type: Type.STRING, description: "The full legal citation (e.g., '5 U.S. 137')." },
                            year: { type: Type.INTEGER, description: "The year the case was decided." },
                            court: { type: Type.STRING, description: "The court that decided the case (e.g., 'U.S. Supreme Court')." },
                            summary: { type: Type.STRING, description: "A brief summary of the case facts and holding." },
                            keyPrinciple: { type: Type.STRING, description: "The key legal principle or rule established by the case." }
                        },
                        required: ["caseName", "citation", "year", "court", "summary", "keyPrinciple"]
                    }
                }
            }
        });

        const jsonText = response.text.trim();
        const cases: HistoricalCase[] = JSON.parse(jsonText);
        return cases;

    } catch (error) {
        console.error("Error searching case law:", error);
        throw new Error("Failed to search historical case law. The AI may have returned an unexpected format.");
    }
};

export const createChatSession = (caseContext: string, aiRole: 'Plaintiff' | 'Defendant'): Chat => {
    const systemInstruction = `You are an expert attorney representing the ${aiRole}. You are participating in an oral argument simulation before Judge Lori Gibson Willard.
    The judge will ask you questions. You must respond in character, advocating for your client's position based *only* on the facts provided below.
    Be respectful, professional, and address the judge as "Your Honor". Your arguments should be persuasive, logical, and confined to the case background. Do not invent new facts.

    ---
    CASE BACKGROUND:
    ${caseContext}
    ---
    `;

    const chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction: systemInstruction,
        },
    });
    return chat;
};