
import type { HistoryItem } from '../types';

const getHistoryKey = (userId: string) => `judicial_ai_history_${userId}`;

export const getHistory = (userId: string): HistoryItem[] => {
    try {
        const historyStr = localStorage.getItem(getHistoryKey(userId));
        const history = historyStr ? JSON.parse(historyStr) : [];
        // Sort by timestamp descending (newest first)
        return history.sort((a: HistoryItem, b: HistoryItem) => b.timestamp - a.timestamp);
    } catch (e) {
        return [];
    }
};

export const addHistoryItem = (userId: string, item: Omit<HistoryItem, 'id' | 'timestamp'>): void => {
    if (!userId) return;
    try {
        const history = getHistory(userId);
        const newHistoryItem: HistoryItem = {
            ...item,
            id: Date.now().toString(),
            timestamp: Date.now(),
        };
        const updatedHistory = [newHistoryItem, ...history];
        localStorage.setItem(getHistoryKey(userId), JSON.stringify(updatedHistory));
    } catch (error) {
        console.error("Failed to save history item:", error);
    }
};
